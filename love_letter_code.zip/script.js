const env = document.getElementById("env");
const btn = document.getElementById("open");

btn.onclick = () => {
  env.classList.add("open");
  btn.style.display = "none";
  setTimeout(type, 1400);
};

const text = document.getElementById("text");
const msg = [
  "Thank you for being you.",
  "You make ordinary days feel",
  "like tiny celebrations.",
  "Never forget how loved you are."
].join(" ");

let i = 0;
function type() {
  text.textContent = msg.slice(0, ++i);
  if (i < msg.length) setTimeout(type, 55);
}

const to = new URLSearchParams(location.search)
  .get("to");

if (to) {
  document.getElementById("to").textContent =
    "A letter for " + to;
}

function petal() {
  const p = document.createElement("div");
  const r = Math.random();
  p.className = "petal";
  p.textContent = "\u2665";
  p.style.left = r * 100 + "vw";
  p.style.fontSize = 14 + r * 18 + "px";
  p.style.animationDuration = 4 + r * 4 + "s";
  document.body.append(p);
  setTimeout(() => p.remove(), 8000);
}
setInterval(petal, 350);
