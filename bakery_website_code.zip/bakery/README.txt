WiggleStudioo - Cute Bakery Website
Double click index.html to open it. Needs internet for the Pacifico font.
Photos are in the img folder: swap them for your own!
Extra photos in img/ (pink_donut, tart, waffle...) are for the 'add a fourth treat' challenge.
YouTube: https://youtube.com/@wigglestudioo
