const burger = document.getElementById("burger");
const links = document.getElementById("links");

burger.onclick = () => {
  links.classList.toggle("open");
};

const count = document.getElementById("count");
let total = 0;

document.querySelectorAll(".add").forEach(b => {
  b.onclick = () => {
    total++;
    count.textContent = total;
    b.textContent = "Added \u2665";
  };
});

const nav = document.getElementById("nav");

window.onscroll = () => {
  nav.classList.toggle("shadow", scrollY > 20);
};
