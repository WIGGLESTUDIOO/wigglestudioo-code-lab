WiggleStudioo - 5 Cute Mini Games
Double click any .html file to play. Open it in a text editor to change the symbols, speed and colors (look at the top of the script).
YouTube: https://youtube.com/@wigglestudioo
