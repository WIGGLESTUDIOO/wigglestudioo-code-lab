const pass = document.getElementById("pass");
const eye = document.getElementById("eye");

eye.onclick = () => {
  const hidden = pass.type === "password";
  pass.type = hidden ? "text" : "password";
  eye.textContent = hidden ? "Hide" : "Show";
};

const form = document.getElementById("form");
const email = document.getElementById("email");

function fail(input, msg) {
  const f = input.parentElement;
  f.classList.add("error");
  f.querySelector(".err").textContent = msg;
}
function clear(input) {
  const f = input.parentElement;
  f.classList.remove("error");
  f.querySelector(".err").textContent = "";
}
form.onsubmit = (e) => {
  e.preventDefault();
  let ok = true;
  clear(email);
  clear(pass);
  if (!/^\S+@\S+\.\S+$/.test(email.value)) {
    fail(email, "Enter a valid email");
    ok = false;
  }
  if (pass.value.length < 6) {
    fail(pass, "Use 6+ characters");
    ok = false;
  }
  if (ok) success();
};

function success() {
  const btn = document.getElementById("go");
  btn.textContent = "Logging in...";
  setTimeout(() => {
    btn.textContent = "Welcome back!";
  }, 1200);
}

const card = document.getElementById("card");
const swap = document.getElementById("swap");
const title = document.getElementById("title");
const sub = document.getElementById("sub");
const go = document.getElementById("go");

swap.onclick = (e) => {
  e.preventDefault();
  const up = card.classList.toggle("signup");
  title.textContent = up
    ? "Create account" : "Welcome back";
  sub.textContent = up
    ? "Sign up to get started"
    : "Log in to continue";
  go.textContent = up ? "Sign up" : "Log in";
  swap.textContent = up ? "Log in" : "Sign up";
};

const bar = document.querySelector(".bar i");

pass.oninput = () => {
  const v = pass.value;
  let s = 0;
  if (v.length >= 6) s++;
  if (/[0-9]/.test(v)) s++;
  if (/[A-Z]/.test(v)) s++;
  const c = ["#ff7a90", "#ffb86c", "#7af0a8"];
  bar.style.width = s * 33.3 + "%";
  bar.style.background = c[Math.max(0, s - 1)];
};
