LOGIN & SIGN UP PAGE - WiggleStudioo
Open index.html in your browser. Keep the 3 files in the same folder.
This is the front end only (no server), so the form only shows messages.
Optional: for the exact Poppins font, add a Google Fonts link for Poppins inside the head of index.html. Without it, a similar font is used.
