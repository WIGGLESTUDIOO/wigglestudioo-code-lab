const words = ["websites", "apps", "cool stuff"];
const role = document.getElementById("role");
let w = 0, i = 0, deleting = false;

function type() {
  const word = words[w];
  role.textContent = word.slice(0, i);

  if (!deleting && i === word.length) {
    deleting = true;
    return setTimeout(type, 1200);
  }
  if (deleting && i === 0) {
    deleting = false;
    w = (w + 1) % words.length;
  }
  i += deleting ? -1 : 1;
  setTimeout(type, deleting ? 50 : 100);
}
type();

const targets = document.querySelectorAll(
  "section h2, #about p, .skills, .card, form"
);
const io = new IntersectionObserver((list) => {
  list.forEach((e) => {
    if (e.isIntersecting) {
      e.target.classList.add("show");
    }
  });
});
targets.forEach((t) => {
  t.classList.add("reveal");
  io.observe(t);
});

const btn = document.getElementById("theme");

btn.onclick = () => {
  const b = document.body;
  const light = b.dataset.theme !== "light";
  b.dataset.theme = light ? "light" : "";
  btn.textContent = light ? "☾" : "☀";
};

const form = document.getElementById("form");
const msg = document.getElementById("msg");

form.onsubmit = (e) => {
  e.preventDefault();
  msg.textContent = "Thanks! I'll reply soon ♥";
  form.reset();
};
