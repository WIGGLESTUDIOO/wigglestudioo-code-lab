PORTFOLIO WEBSITE - WiggleStudioo
Open index.html in your browser. Keep the 3 files in the same folder.
Change the name and text to make it yours.
Optional: for the exact Poppins font, add a Google Fonts link in the head of index.html.
