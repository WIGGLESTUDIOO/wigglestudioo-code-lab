const cam = document.getElementById("cam");
const count = document.getElementById("count");

async function start() {
  const stream = await navigator.mediaDevices
    .getUserMedia({ video: true });
  cam.srcObject = stream;
}
start();

const wait = ms =>
  new Promise(r => setTimeout(r, ms));

async function countdown() {
  for (let n = 3; n > 0; n--) {
    count.textContent = n;
    await wait(1000);
  }
  count.textContent = "";
}

const shot = document.getElementById("shot");
const strip = document.getElementById("strip");

function snap() {
  shot.width = cam.videoWidth;
  shot.height = cam.videoHeight;
  const g = shot.getContext("2d");
  g.translate(shot.width, 0);
  g.scale(-1, 1);
  g.drawImage(cam, 0, 0);
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.font = shot.width * 0.13 + "px serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  placed.forEach(s => {
    const x = parseFloat(s.style.left) / 100;
    const y = parseFloat(s.style.top) / 100;
    g.fillText(s.textContent,
      x * shot.width, y * shot.height);
  });
  const flash = document.getElementById("flash");
  flash.classList.remove("go");
  void flash.offsetWidth;
  flash.classList.add("go");
  const img = new Image();
  img.src = shot.toDataURL("image/png");
  strip.append(img);
}

document.getElementById("snap").onclick =
  async () => {
    strip.innerHTML = "";
    for (let i = 0; i < 3; i++) {
      await countdown();
      snap();
      await wait(500);
    }
  };

const booth = document.getElementById("booth");
const placed = [];

document.querySelectorAll(".stk").forEach(b => {
  b.onclick = () => {
    const s = document.createElement("div");
    s.className = "on-booth";
    s.textContent = b.textContent;
    s.style.left = 20 + Math.random() * 60 + "%";
    s.style.top = 20 + Math.random() * 60 + "%";
    booth.append(s);
    placed.push(s);
  };
});

document.getElementById("save").onclick = () => {
  const imgs = [...strip.children];
  const w = 320, h = 240, p = 16;
  const out = document.createElement("canvas");
  out.width = w + p * 2;
  out.height = (h + p) * imgs.length + p;
  const g = out.getContext("2d");
  g.fillStyle = "#fff";
  g.fillRect(0, 0, out.width, out.height);
  imgs.forEach((im, i) =>
    g.drawImage(im, p, p + i * (h + p), w, h));
  const a = document.createElement("a");
  a.download = "photo-strip.png";
  a.href = out.toDataURL();
  a.click();
};
